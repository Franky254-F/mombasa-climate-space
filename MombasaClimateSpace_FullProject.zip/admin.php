<?php include 'config.php'; ?>
<!DOCTYPE html><html><body>
<h1>Admin Dashboard</h1>
<h2>Registrations</h2>
<table border='1'>
<tr><th>ID</th><th>Name</th><th>Email</th><th>Contact</th></tr>
<?php $r=mysqli_query($conn,'SELECT * FROM registrations ORDER BY id DESC');
while($row=mysqli_fetch_assoc($r)){ echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['email']}</td><td>{$row['contact']}</td></tr>"; } ?>
</table>
<h2>Messages</h2>
<table border='1'>
<tr><th>ID</th><th>Name</th><th>Email</th><th>Message</th></tr>
<?php $m=mysqli_query($conn,'SELECT * FROM messages ORDER BY id DESC');
while($row=mysqli_fetch_assoc($m)){ echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['email']}</td><td>{$row['message']}</td></tr>"; } ?>
</table>
</body></html>