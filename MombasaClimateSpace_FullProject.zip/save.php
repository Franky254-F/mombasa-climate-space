<?php
include 'config.php';
$stmt=mysqli_prepare($conn,"INSERT INTO registrations(name,email,contact) VALUES(?,?,?)");
mysqli_stmt_bind_param($stmt,"sss",$_POST['name'],$_POST['email'],$_POST['contact']);
mysqli_stmt_execute($stmt);
header("Location: register.php?success=1");
?>