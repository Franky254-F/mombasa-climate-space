<?php
include 'config.php';
$stmt=mysqli_prepare($conn,"INSERT INTO messages(name,email,message) VALUES(?,?,?)");
mysqli_stmt_bind_param($stmt,"sss",$_POST['name'],$_POST['email'],$_POST['message']);
mysqli_stmt_execute($stmt);
header("Location: index.php?sent=1");
?>