<!DOCTYPE html><html><body>
<h1>Mombasa Climate Space</h1>
<p>Database-enabled homepage.</p>
<form action='contact.php' method='POST'>
<input name='name' placeholder='Name' required><br><br>
<input name='email' type='email' placeholder='Email' required><br><br>
<textarea name='message' placeholder='Message' required></textarea><br><br>
<button type='submit'>Send Message</button>
</form>
<p><a href='register.php'>Register With Us</a></p>
<p><a href='admin.php'>Admin Dashboard</a></p>
</body></html>