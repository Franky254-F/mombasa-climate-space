<?php
$conn=mysqli_connect("localhost","root","","mombasa_climate_space");
if(!$conn){die("Connection failed");}
?>