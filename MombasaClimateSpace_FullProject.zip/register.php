<!DOCTYPE html><html><body>
<h1>Mombasa Climate Space Registration</h1>
<form action='save.php' method='POST'>
<input name='name' placeholder='Name' required><br><br>
<input name='email' type='email' placeholder='Email' required><br><br>
<input name='contact' placeholder='Contact' required><br><br>
<button type='submit'>Register</button>
</form>
</body></html>